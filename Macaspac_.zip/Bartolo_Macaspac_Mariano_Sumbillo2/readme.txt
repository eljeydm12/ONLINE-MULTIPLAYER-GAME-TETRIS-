
DEVELOPERS:

BARTOLO, ALLEN
MARIANO, JARENZ 
MACASPAC, LANCE JERELL
SUMBILLO, ROLLY


____________________________________________________________________________________________________________________________________________________________________________________________

Tetris Web Application
Welcome to the Tetris Web Application! This project aims to provide a dynamic and engaging gaming experience by implementing the classic Tetris game with real-time updates, WebSocket communication, and integration with external APIs.

Features

Classic Tetris Gameplay: Enjoy the timeless gameplay of Tetris with dynamic piece movement, rotation, and collision detection.

Real-time Updates: Experience real-time score updates, level progression, and multiplayer interactions through WebSocket implementation.

Web API Integration: Fetch and display data from external APIs, enhancing the user experience with dynamically updated content.

Responsive Design: Play seamlessly across different devices and screen sizes with a responsive and visually appealing layout.

Intuitive Controls: Easily navigate and interact with the game using intuitive controls for piece movement and rotation.

Event Handling: Manage game events such as piece placement, line clearing, and game over with real-time broadcasting to connected players.

Program Structure
The project is structured into client-side and server-side components:

Client-Side:

index.html: Game interface structure.
styles.css: Styling for the game interface.
arena.js: Manages the game arena and updates the game state.
connection-manager.js: Handles WebSocket connections to the server.
events.js: Manages game events such as piece movement and rotation.
main.js: Entry point for the client-side application, initializes the game.
player.js: Manages player-specific data and actions.
tetris.js: Implements core Tetris game logic.
tetris-manager.js: Manages multiple Tetris game instances and player interactions.

Server-Side:

client.js: Manages individual client connections.
main.js: Sets up the WebSocket server and manages connections.
session.js: Manages game sessions, including adding and removing players.



____________________________________________________________________________________________________________________________________________________________________________________________
Installation
Follow these steps to get the Tetris Web Application running on your local machine:

1. Clone the Repository: 
git clone <URL>


2. Navigate to the Project Directory: 
cd tetris-web-app


3. Install Dependencies:
npm install


4. Start the Server: Launch the WebSocket server:
node server/main.js


5. Open the Game in Your Browser: Open your web browser and enter the URL:
file:///path/to/tetris-web-app/index.html




