class Tetris {
    constructor(element) {
        this.element = element;
        this.canvas = element.querySelector('canvas');
        this.context = this.canvas.getContext('2d');
        this.context.scale(20, 20);

        // Load background image
        this.bgImage = new Image();
        this.bgImage.src = 'bg.png'; // Replace 'bg.png' with the path to your image
        this.bgImage.onload = () => {
            this.draw(); // Draw the initial state once the background image has loaded
        };

        this.arena = new Arena(12, 20);
        this.player = new Player(this);
        this.player.events.listen('score', score => {
            this.updateScore(score);
        });

        this.colors = [
            null,
            '#FF0D72',
            '#0DC2FF',
            '#0DFF72',
            '#F538FF',
            '#FF8E0D',
            '#FFE138',
            '#3877FF',
        ];

        let lastTime = 0;
        this._update = (time = 0) => {
            const deltaTime = time - lastTime;
            lastTime = time;

            this.player.update(deltaTime);

            this.draw();
            requestAnimationFrame(this._update);
        };

        this.updateScore(0);
    }

    draw() {
        // Clear the canvas before drawing
        this.context.clearRect(0, 0, this.canvas.width, this.canvas.height);
        
        // Draw background image
        if (this.bgImage.complete) {
            this.context.drawImage(this.bgImage, 0, 0, this.canvas.width / 20, this.canvas.height / 20);
        }

        this.drawMatrix(this.arena.matrix, { x: 0, y: 0 });
        this.drawMatrix(this.player.matrix, this.player.pos);
    }

    drawMatrix(matrix, offset) {
        matrix.forEach((row, y) => {
            row.forEach((value, x) => {
                if (value !== 0) {
                    this.context.fillStyle = this.colors[value];
                    this.context.fillRect(x + offset.x,
                        y + offset.y,
                        1, 1);
                }
            });
        });
    }

    run() {
        this._update();
    }

    serialize() {
        return {
            arena: {
                matrix: this.arena.matrix,
            },
            player: {
                matrix: this.player.matrix,
                pos: this.player.pos,
                score: this.player.score,
            },
        };
    }

    unserialize(state) {
        this.arena = Object.assign(state.arena);
        this.player = Object.assign(state.player);
        this.updateScore(this.player.score);
        this.draw();
    }

    updateScore(score) {
        this.element.querySelector('.score').innerText = score;
    }
}
